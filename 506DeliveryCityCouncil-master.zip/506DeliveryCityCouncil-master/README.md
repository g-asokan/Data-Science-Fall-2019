# 506DeliveryCityCouncil
Run getData.py to clean data(data preprocessing).

In the data folder, it add tags or whether you are a member of PAC, or Union PACs, or individuals.

ocpf.py gives whether the contributer is a lobbyist or not.

In the web folder, we used the codes to convert address to Geopoints(latitude and longtitudes). 

All the visualization are done by tableau. 
